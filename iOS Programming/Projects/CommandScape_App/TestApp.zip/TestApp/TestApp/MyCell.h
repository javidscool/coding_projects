//
//  MyCell.h
//  TestApp
//
//  Created by Javid Shamloo on 10/3/16.
//  Copyright © 2016 CommandScape. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCell : UITableViewCell

@end
