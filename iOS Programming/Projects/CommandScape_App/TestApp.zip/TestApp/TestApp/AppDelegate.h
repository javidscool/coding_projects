//
//  AppDelegate.h
//  TestApp
//
//  Created by Javid Shamloo on 10/2/16.
//  Copyright © 2016 CommandScape. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

