//
//  ViewController.h
//  TestApp
//
//  Created by Javid Shamloo on 10/2/16.
//  Copyright © 2016 CommandScape. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ImageViewController : UITableViewController

@end

